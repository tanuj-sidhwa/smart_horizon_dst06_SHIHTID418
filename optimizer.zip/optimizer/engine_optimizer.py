"""
optimizer.engine_optimizer
===========================
This is the requirements -> design translator.

You give it what you WANT the engine to do (target thrust, an
allowable thrust band, a max exhaust temperature, an allowable exhaust
velocity band, and which of {TSFC, thermal efficiency, fuel flow,
compressor power, thrust-to-weight} to weight most) and it runs NSGA-II
over the FULL design space (all 19 fields — both the 6 thermodynamic
variables and the 13 geometric variables, since geometry now feeds a
real mass / thrust-to-weight objective via core.geometry) through:

    design -> core.engine.run_engine (physics)
           -> ml.correction_model.correct (CFD-corrected performance)
           -> objectives / constraints (from your Requirements)
           -> NSGA-II

...and returns the Pareto-optimal set of designs plus one recommended
"best compromise" design, ready to export for CAD (cad/freecad_generate.py).

Objectives (all minimized internally; efficiency/T:W are negated):
    1. |thrust - target_thrust|
    2. TSFC
    3. -thermal_efficiency
    4. fuel_flow
    5. -thrust_to_weight

Constraints (satisfied when <= 0):
    1. exhaust_temp - max_exhaust_temp
    2. min_exhaust_velocity - exhaust_velocity
    3. exhaust_velocity - max_exhaust_velocity
    4. min_thrust - thrust
    5. thrust - max_thrust
"""

from dataclasses import dataclass, field
from pathlib import Path
import sys
from typing import Dict, List, Optional, Tuple

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from core.engine import run_engine, INPUTS, THERMODYNAMIC_INPUTS, GEOMETRIC_INPUTS  # noqa: E402
from ml.correction_model import correct  # noqa: E402
from optimizer.nsga2 import NSGA2, Individual  # noqa: E402


# Search bounds for every design field, taken from the span of the
# validated CFD dataset (data/cfd_dataset.csv) so the optimizer never
# proposes a design point far outside the region the physics model +
# ML corrector were validated against.
DEFAULT_BOUNDS: Dict[str, Tuple[float, float]] = {
    "compressor_pressure_ratio": (2.0, 5.0),
    "compressor_efficiency": (0.70, 0.85),
    "compressor_diameter_mm": (60.0, 150.0),
    "compressor_blade_count": (8, 20),
    "combustor_length_mm": (50.0, 150.0),
    "combustor_outer_diameter_mm": (80.0, 160.0),
    "combustor_inner_diameter_mm": (40.0, 90.0),
    "combustor_liner_thickness_mm": (0.8, 2.0),
    "combustor_num_injectors": (4, 12),
    "combustor_air_fuel_ratio": (40.0, 80.0),
    "turbine_inlet_temp_K": (800.0, 1200.0),
    "turbine_efficiency": (0.75, 0.88),
    "turbine_blade_count": (11, 23),
    "turbine_hub_tip_ratio": (0.60, 0.85),
    "nozzle_exit_diameter_mm": (30.0, 80.0),
    "mass_flow_kg_s": (0.08, 0.30),
    "rpm": (60000.0, 150000.0),
    "lattice_cell_size_mm": (4.0, 14.0),
    "lattice_density": (0.15, 0.55),
}

INT_FIELDS = (
    "compressor_blade_count",
    "combustor_num_injectors",
    "turbine_blade_count",
)


@dataclass
class Requirements:
    target_thrust_N: float = 50.0
    thrust_band_N: float = 1.0            # +/- band around target -> constraint
    max_exhaust_temp_K: float = 1200.0
    min_exhaust_velocity_m_s: float = 250.0
    max_exhaust_velocity_m_s: float = 450.0

    population_size: int = 80
    generations: int = 100
    random_seed: int = 42

    # Optional: restrict the search to a subset of fields (e.g. only the
    # 6 thermodynamic variables, holding geometry fixed at given values)
    bounds_override: Optional[Dict[str, Tuple[float, float]]] = None
    fixed_fields: Dict[str, float] = field(default_factory=dict)

    @property
    def min_thrust_N(self) -> float:
        return self.target_thrust_N - self.thrust_band_N

    @property
    def max_thrust_N(self) -> float:
        return self.target_thrust_N + self.thrust_band_N


def _evaluate(design: Dict[str, float], req: Requirements, fixed: Dict[str, float]):
    full_design = dict(fixed)
    full_design.update(design)

    physics = run_engine(**full_design)
    corrected = correct(physics)

    thrust = corrected["thrust_N"]
    fuel_flow = corrected["fuel_flow_kg_s"]
    tsfc = corrected["tsfc_kg_N_s"]
    exhaust_temp = corrected["exhaust_temp_K"]
    exhaust_velocity = corrected["exhaust_velocity_m_s"]
    thermal_efficiency = corrected["thermal_efficiency"]
    thrust_to_weight = physics["thrust_to_weight"]  # geometry/mass -> not ML-corrected

    objectives = (
        abs(thrust - req.target_thrust_N),
        tsfc,
        -thermal_efficiency,
        fuel_flow,
        -thrust_to_weight,
    )

    constraints = (
        exhaust_temp - req.max_exhaust_temp_K,
        req.min_exhaust_velocity_m_s - exhaust_velocity,
        exhaust_velocity - req.max_exhaust_velocity_m_s,
        req.min_thrust_N - thrust,
        thrust - req.max_thrust_N,
    )

    extra = {"physics": physics, "corrected": corrected}
    return objectives, constraints, extra


def optimize(req: Requirements, verbose: bool = True) -> Tuple[List[Individual], Dict]:
    bounds = dict(req.bounds_override or DEFAULT_BOUNDS)
    for f in req.fixed_fields:
        bounds.pop(f, None)

    nsga = NSGA2(
        bounds=bounds,
        evaluate_fn=lambda d: _evaluate(d, req, req.fixed_fields),
        population_size=req.population_size,
        generations=req.generations,
        random_seed=req.random_seed,
        int_fields=INT_FIELDS,
    )

    if verbose:
        print(f"Running NSGA-II: pop={req.population_size}, gens={req.generations}, "
              f"variables={len(bounds)}")

    final_pop = nsga.run(verbose=verbose)
    pareto = NSGA2.pareto_front(final_pop)

    best = pick_best_compromise(pareto, req)
    return pareto, best


def pick_best_compromise(pareto: List[Individual], req: Requirements) -> Optional[Dict]:
    """
    Among feasible Pareto-optimal individuals, pick the one closest to
    the thrust target, breaking ties by lowest TSFC. If none are
    feasible, fall back to the least-infeasible individual.
    """
    if not pareto:
        return None

    feasible = [p for p in pareto if p.feasible]
    pool = feasible if feasible else pareto

    def score(ind: Individual):
        thrust_error = ind.objectives[0]
        tsfc = ind.objectives[1]
        violation = ind.violation
        return (violation, thrust_error, tsfc)

    best = min(pool, key=score)
    full_design = dict(req.fixed_fields)
    full_design.update(best.design)
    physics = run_engine(**full_design)
    corrected = correct(physics)

    return {
        "design": full_design,
        "physics": physics,
        "corrected": corrected,
        "objectives": best.objectives,
        "constraints": best.constraints,
        "feasible": best.feasible,
    }


def pareto_to_dataframe(pareto: List[Individual], req: Requirements) -> pd.DataFrame:
    rows = []
    for ind in pareto:
        full_design = dict(req.fixed_fields)
        full_design.update(ind.design)
        physics = ind.extra.get("physics") or run_engine(**full_design)
        corrected = ind.extra.get("corrected") or correct(physics)

        row = dict(full_design)
        row["feasible"] = ind.feasible
        row["thrust_error_N"] = ind.objectives[0]
        row["tsfc_kg_N_s"] = corrected["tsfc_kg_N_s"]
        row["thermal_efficiency"] = corrected["thermal_efficiency"]
        row["fuel_flow_kg_s"] = corrected["fuel_flow_kg_s"]
        row["thrust_to_weight"] = physics["thrust_to_weight"]
        row["thrust_N_corrected"] = corrected["thrust_N"]
        row["exhaust_temp_K_corrected"] = corrected["exhaust_temp_K"]
        row["exhaust_velocity_m_s_corrected"] = corrected["exhaust_velocity_m_s"]
        row["total_mass_kg"] = physics["total_mass_kg"]
        rows.append(row)
    return pd.DataFrame(rows)
