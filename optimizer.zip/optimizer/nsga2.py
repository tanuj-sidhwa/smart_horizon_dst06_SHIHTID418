"""
optimizer.nsga2
================
A compact, dependency-free (numpy only) NSGA-II implementation:
    - Deb's constrained-dominance (feasible beats infeasible; among
      infeasible, smaller total violation wins; among feasible, normal
      Pareto dominance)
    - Fast non-dominated sort
    - Crowding distance
    - Binary tournament selection
    - Simulated-binary-style blend crossover + Gaussian mutation, with
      bound repair (clip)

It is deliberately generic: it knows nothing about turbojets. You give
it:
    - `bounds`: dict[str, (low, high)]  the design variables to search
    - `evaluate_fn(design: dict) -> (objectives: tuple, constraints: tuple, extra: dict)`
      objectives are MINIMIZED; constraints are satisfied when <= 0.

See optimizer/engine_optimizer.py for the turbojet-specific wiring
(physics model + ML correction + requirement-based objectives).
"""

import random
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Tuple

import numpy as np


@dataclass
class Individual:
    design: Dict[str, float]
    objectives: Tuple[float, ...] = field(default_factory=tuple)
    constraints: Tuple[float, ...] = field(default_factory=tuple)
    extra: Dict = field(default_factory=dict)
    rank: int = 0
    crowding: float = 0.0

    @property
    def violation(self) -> float:
        return sum(v for v in self.constraints if v > 0)

    @property
    def feasible(self) -> bool:
        return self.violation == 0.0


def constraint_dominates(a: Individual, b: Individual) -> bool:
    va, vb = a.violation, b.violation
    fa, fb = va == 0.0, vb == 0.0
    if fa and not fb:
        return True
    if not fa and fb:
        return False
    if not fa and not fb:
        return va < vb
    return dominates(a, b)


def dominates(a: Individual, b: Individual) -> bool:
    no_worse = all(x <= y for x, y in zip(a.objectives, b.objectives))
    strictly_better = any(x < y for x, y in zip(a.objectives, b.objectives))
    return no_worse and strictly_better


def fast_non_dominated_sort(pop: List[Individual]) -> List[List[Individual]]:
    fronts: List[List[Individual]] = [[]]
    dominated_by = {id(p): [] for p in pop}
    domination_count = {id(p): 0 for p in pop}

    for p in pop:
        for q in pop:
            if p is q:
                continue
            if constraint_dominates(p, q):
                dominated_by[id(p)].append(q)
            elif constraint_dominates(q, p):
                domination_count[id(p)] += 1
        if domination_count[id(p)] == 0:
            p.rank = 0
            fronts[0].append(p)

    i = 0
    while fronts[i]:
        next_front = []
        for p in fronts[i]:
            for q in dominated_by[id(p)]:
                domination_count[id(q)] -= 1
                if domination_count[id(q)] == 0:
                    q.rank = i + 1
                    next_front.append(q)
        i += 1
        fronts.append(next_front)
    return [f for f in fronts if f]


def crowding_distance(front: List[Individual]) -> None:
    n = len(front)
    if n == 0:
        return
    for p in front:
        p.crowding = 0.0
    n_obj = len(front[0].objectives)
    for m in range(n_obj):
        front.sort(key=lambda p: p.objectives[m])
        front[0].crowding = float("inf")
        front[-1].crowding = float("inf")
        obj_min = front[0].objectives[m]
        obj_max = front[-1].objectives[m]
        spread = obj_max - obj_min
        if spread == 0:
            continue
        for i in range(1, n - 1):
            front[i].crowding += (
                front[i + 1].objectives[m] - front[i - 1].objectives[m]
            ) / spread


def assign_rank_and_crowding(pop: List[Individual]) -> List[List[Individual]]:
    fronts = fast_non_dominated_sort(pop)
    for front in fronts:
        crowding_distance(front)
    return fronts


def crowded_comparison_better(a: Individual, b: Individual) -> bool:
    if a.rank != b.rank:
        return a.rank < b.rank
    return a.crowding > b.crowding


def tournament_selection(pop: List[Individual], k: int = 2) -> Individual:
    candidates = random.sample(pop, k)
    best = candidates[0]
    for c in candidates[1:]:
        if crowded_comparison_better(c, best):
            best = c
    return best


class NSGA2:
    def __init__(
        self,
        bounds: Dict[str, Tuple[float, float]],
        evaluate_fn: Callable[[Dict[str, float]], Tuple[Tuple, Tuple, Dict]],
        population_size: int = 80,
        generations: int = 100,
        crossover_prob: float = 0.9,
        mutation_prob: float = 0.2,
        mutation_sigma: float = 0.10,
        random_seed: int = 42,
        int_fields: Tuple[str, ...] = (),
    ):
        self.bounds = bounds
        self.variables = list(bounds.keys())
        self.evaluate_fn = evaluate_fn
        self.population_size = population_size
        self.generations = generations
        self.crossover_prob = crossover_prob
        self.mutation_prob = mutation_prob
        self.mutation_sigma = mutation_sigma
        self.int_fields = set(int_fields)

        random.seed(random_seed)
        np.random.seed(random_seed)

    # -- design vector helpers -------------------------------------
    def _random_design(self) -> Dict[str, float]:
        d = {}
        for v in self.variables:
            lo, hi = self.bounds[v]
            val = random.uniform(lo, hi)
            d[v] = round(val) if v in self.int_fields else val
        return d

    def _clip(self, design: Dict[str, float]) -> Dict[str, float]:
        out = {}
        for v in self.variables:
            lo, hi = self.bounds[v]
            val = max(lo, min(hi, design[v]))
            out[v] = round(val) if v in self.int_fields else val
        return out

    def _evaluate(self, design: Dict[str, float]) -> Individual:
        design = self._clip(design)
        try:
            objectives, constraints, extra = self.evaluate_fn(design)
        except Exception:  # noqa: BLE001 - invalid design point, penalize heavily
            objectives = tuple([1e12] * 5)
            constraints = tuple([1e12])
            extra = {"invalid": True}
        return Individual(design=design, objectives=objectives, constraints=constraints, extra=extra)

    # -- genetic operators --------------------------------------------
    def _crossover(self, a: Dict[str, float], b: Dict[str, float]):
        child1, child2 = dict(a), dict(b)
        if random.random() < self.crossover_prob:
            for v in self.variables:
                if random.random() < 0.5:
                    child1[v], child2[v] = b[v], a[v]
                else:
                    alpha = random.random()
                    val1 = alpha * a[v] + (1 - alpha) * b[v]
                    val2 = alpha * b[v] + (1 - alpha) * a[v]
                    child1[v], child2[v] = val1, val2
        return self._clip(child1), self._clip(child2)

    def _mutate(self, design: Dict[str, float]) -> Dict[str, float]:
        out = dict(design)
        for v in self.variables:
            if random.random() < self.mutation_prob:
                lo, hi = self.bounds[v]
                span = hi - lo
                out[v] = out[v] + random.gauss(0, self.mutation_sigma * span)
        return self._clip(out)

    # -- main loop -------------------------------------------------
    def _initial_population(self) -> List[Individual]:
        return [self._evaluate(self._random_design()) for _ in range(self.population_size)]

    def _create_offspring(self, pop: List[Individual]) -> List[Individual]:
        offspring = []
        while len(offspring) < self.population_size:
            p1 = tournament_selection(pop)
            p2 = tournament_selection(pop)
            c1, c2 = self._crossover(p1.design, p2.design)
            c1, c2 = self._mutate(c1), self._mutate(c2)
            offspring.append(self._evaluate(c1))
            if len(offspring) < self.population_size:
                offspring.append(self._evaluate(c2))
        return offspring

    def _environmental_selection(self, combined: List[Individual]) -> List[Individual]:
        fronts = assign_rank_and_crowding(combined)
        new_pop: List[Individual] = []
        for front in fronts:
            if len(new_pop) + len(front) <= self.population_size:
                new_pop.extend(front)
            else:
                remaining = self.population_size - len(new_pop)
                front_sorted = sorted(front, key=lambda p: -p.crowding)
                new_pop.extend(front_sorted[:remaining])
                break
        return new_pop

    def run(self, verbose: bool = True) -> List[Individual]:
        pop = self._initial_population()
        assign_rank_and_crowding(pop)

        for gen in range(self.generations):
            offspring = self._create_offspring(pop)
            combined = pop + offspring
            pop = self._environmental_selection(combined)

            if verbose and (gen % max(1, self.generations // 10) == 0 or gen == self.generations - 1):
                n_feasible = sum(1 for p in pop if p.feasible)
                print(f"  gen {gen+1:4d}/{self.generations}  feasible: {n_feasible}/{len(pop)}")

        return pop

    @staticmethod
    def pareto_front(pop: List[Individual]) -> List[Individual]:
        return [p for p in pop if p.rank == 0]
